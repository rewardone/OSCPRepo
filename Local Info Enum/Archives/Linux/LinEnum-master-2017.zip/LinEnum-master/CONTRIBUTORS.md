Many thanks to @roo7break (http://roo7break.co.uk/) for the added reporting functionality added to version 3 (support discontinued in later versions).
