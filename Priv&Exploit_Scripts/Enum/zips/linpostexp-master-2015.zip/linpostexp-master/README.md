# Linux post exploitation enumeration and exploit checking tools

The *Updated* date is the date the corresponding tool was updated in *this* repository.


## linenum.sh

Source: https://github.com/rebootuser/LinEnum

Author: Rebootuser

Updated: Jun 15 2015


## linprivchecker.py

Source: www.securitysift.com/download/linuxprivchecker.py

Author: Mike Czumak (Security Sift)

Updated: Jun 15 2015


## linexpsuggester.pl

Source: https://github.com/PenturaLabs/Linux_Exploit_Suggester

Author: PenturaLabs

Updated: Jun 15 2015


## linexpchecker.py

Source: https://github.com/inquisb/miscellaneous

Author: Bernardo Damele (inquisb)

Updated: Jun 15 2015

Oleg Mitrofanov backported this script to work with Python 2.3.4

## unixprivcheck.tgz

Source: https://github.com/pentestmonkey/unix-privesc-check

Author: Pentestmonkey

Updated: Jun 15 2015

